Snake Battle — CrazyGames HTML5 package (repaired)

Fixes in this build
- Changed Flutter base URL from / to ./ so game resources resolve inside the CrazyGames game iframe.
- Changed manifest, icon, and Flutter bootstrap references to package-relative URLs.
- Changed Flutter CanvasKit base URL from /canvaskit/ to canvaskit/.
- Corrected SDK order: await CrazyGames.SDK.init() before accessing SDK.game or calling loadingStart().
- Start Flutter only after SDK initialization completes (with an 8-second fallback if SDK loading is blocked).
- Start loading tracking after SDK initialization; stop loading and trigger the first gameplayStart when the game reports it is ready.
- Added safe handling for gameplay start/stop and midgame ad failures.
- Kept the compiled Flutter game bundle and gameplay assets unchanged.

Validation
- ZIP integrity checked.
- All local relative file references checked against package files.
- JavaScript syntax checked with Node.js.
- Not run inside CrazyGames Preview; final SDK detection and QA acceptance must be confirmed there.
