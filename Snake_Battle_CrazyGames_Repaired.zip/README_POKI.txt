Snake Battle — Poki Web Build

This package is the Flutter Web build intended for Poki upload.

Controls:
- Two circular virtual joysticks are part of the existing compiled Flutter game:
  - Left joystick: movement + turbo (TURBO center indicator).
  - Right joystick: movement direction.
- The web page now disables browser scrolling/gesture interception over the game surface
  so touch and pointer input can reach the Flutter game controls.

Poki SDK:
- The official Poki SDK v2 script remains included in index.html.
- The compiled game retains its existing Poki init, gameLoadingFinished,
  commercialBreak, gameplayStop, and gameplayStart calls.

Important:
- main.dart.js and all game assets are preserved from the supplied Poki build.
- Only index.html was adjusted for mobile touch handling and viewport behavior.
- This archive was integrity-checked, but a live Poki portal/device playtest is still
  required before public release.
